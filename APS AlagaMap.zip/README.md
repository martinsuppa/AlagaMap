# 🌊 AlagaMap

Aplicação web colaborativa para mapeamento de alagamentos urbanos em tempo real.
Trabalho de Atividades Práticas Supervisionadas (APS) — Ciência da Computação - UNIP.

---

## 📋 Pré-requisitos

Antes de rodar, instale no seu computador:

1. **Node.js** (versão 18 ou superior) — [Baixe aqui](https://nodejs.org/)
2. Verifique a instalação abrindo o terminal e digitando:
   ```
   node --version
   npm --version
   ```

---

## 🚀 Como rodar (3 passos)

### 1) Abrir o terminal nesta pasta
- No Windows: clique com botão direito dentro desta pasta → **"Abrir no Terminal"** (ou abra o CMD/PowerShell e use `cd` até chegar nesta pasta)

### 2) Instalar as dependências
Digite no terminal e aperte Enter:
```
npm install
```
> Vai demorar 1-2 minutos. Vai criar uma pasta `node_modules`.

### 3) Iniciar o servidor
```
npm run dev
```
> Vai aparecer algo como `Local: http://localhost:5173/`

### 4) Abrir no navegador
Acesse [http://localhost:5173](http://localhost:5173) no Chrome ou Edge.

---

## 🔐 Configuração do Firebase

O Firebase já está configurado em `src/services/firebase.js`. Você poderá:
- Criar uma conta com e-mail e senha
- Fazer login
- Reportar alagamentos no mapa
- Ver reportes de outros usuários em tempo real

> ⚠️ Se preferir usar seu próprio projeto Firebase, basta substituir as credenciais no arquivo `src/services/firebase.js`.

---

## 🎯 Funcionalidades

- ✅ Cadastro e login com e-mail/senha (Firebase Auth)
- ✅ Mapa interativo (Leaflet + OpenStreetMap)
- ✅ Busca de endereço (geocodificação via Nominatim)
- ✅ Reportar alagamento clicando no mapa (3 níveis: leve, moderado, grave)
- ✅ Endereço auto-preenchido via geocodificação reversa
- ✅ Feed em tempo real de reportes (Firestore)
- ✅ Reportes ativos por 6 horas no mapa
- ✅ Detecção automática de áreas frequentes de alagamento (3+ ocorrências em 100m, últimos 30 dias)
- ✅ Alertas de chuva via API Open-Meteo
- ✅ Estatísticas em tempo real

---

## 📂 Estrutura do projeto

```
APS Final/
├── src/
│   ├── components/        # Componentes React (Mapa, Modal, Busca, Alerta)
│   ├── contexts/          # Contexto de autenticação
│   ├── pages/             # Páginas (Login, Home)
│   ├── services/          # Firebase + utilitários geográficos
│   ├── App.jsx            # Rotas principais
│   └── main.jsx           # Ponto de entrada
├── public/                # Arquivos estáticos
├── index.html             # HTML raiz
├── package.json           # Dependências
└── vite.config.js         # Configuração do Vite
```

---

## 🛠️ Tecnologias usadas

- **React 19** + **Vite** — interface e build
- **Firebase** (Auth + Firestore) — backend e tempo real
- **Leaflet + React-Leaflet** — mapa interativo
- **OpenStreetMap / Nominatim** — geocodificação
- **Open-Meteo** — previsão do tempo
- **React Router** — navegação
- **React Toastify** — notificações

---

## 👥 Autores

- Gustavo Henrique Magalhães Silva — RA F140HE-2
- Rodrigo Biceglia Valentim Junior — RA N6004H-8
- Martin Luiz Valério Suppa — RA N54725-1

UNIP - Paraíso | 2026
