import { useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup, Circle, Tooltip, useMapEvents, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

const severityColors = {
  leve: "#ffc107",
  moderado: "#ff9800",
  grave: "#f44336",
};

const severityLabels = {
  leve: "Leve",
  moderado: "Moderado",
  grave: "Grave",
};

function createIcon(severity) {
  const color = severityColors[severity] || "#1a73e8";
  return L.divIcon({
    className: "custom-marker",
    html: `<div style="
      background: ${color};
      width: 28px;
      height: 28px;
      border-radius: 50%;
      border: 3px solid white;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 14px;
    ">🌊</div>`,
    iconSize: [28, 28],
    iconAnchor: [14, 14],
  });
}

function MapClickHandler({ onMapClick }) {
  useMapEvents({
    click(e) {
      onMapClick(e.latlng);
    },
  });
  return null;
}

function FlyToLocation({ flyTo }) {
  const map = useMap();
  useEffect(() => {
    if (flyTo) {
      map.flyTo([flyTo.lat, flyTo.lng], 18, { duration: 1.5 });
    }
  }, [flyTo, map]);
  return null;
}

function formatDate(timestamp) {
  if (!timestamp) return "";
  const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
  return date.toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function FloodMap({ reports, onMapClick, center, flyTo, frequentAreas = [] }) {
  return (
    <MapContainer
      center={center}
      zoom={13}
      style={{ height: "100%", width: "100%" }}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <MapClickHandler onMapClick={onMapClick} />
      <FlyToLocation flyTo={flyTo} />
      {frequentAreas.map((area, i) => (
        <Circle
          key={`freq-${i}`}
          center={[area.lat, area.lng]}
          radius={area.radius}
          pathOptions={{
            color: "#d32f2f",
            fillColor: "#f44336",
            fillOpacity: 0.25,
            weight: 2,
          }}
        >
          <Tooltip direction="top" sticky>
            <strong>⚠️ Região com histórico de alagamentos</strong>
            <br />
            {area.count} ocorrências nos últimos 30 dias
          </Tooltip>
        </Circle>
      ))}
      {reports.map((report) => (
        <Marker
          key={report.id}
          position={[report.lat, report.lng]}
          icon={createIcon(report.severity)}
        >
          <Popup>
            <div style={{ minWidth: 180 }}>
              <strong style={{ fontSize: 15 }}>
                {severityLabels[report.severity]} 🌊
              </strong>
              <p style={{ margin: "8px 0 4px", fontSize: 13 }}>
                {report.description || "Sem descrição"}
              </p>
              <small style={{ color: "#666" }}>
                📍 {report.address || "Local não informado"}
              </small>
              <br />
              <small style={{ color: "#888" }}>
                👤 {report.userName} — {formatDate(report.createdAt)}
              </small>
            </div>
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}
