import { useState, useEffect } from "react";
import "./ReportModal.css";

export default function ReportModal({ position, onSubmit, onClose }) {
  const [severity, setSeverity] = useState("moderado");
  const [description, setDescription] = useState("");
  const [address, setAddress] = useState(position.address || "");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (position.address) {
      setAddress(position.address);
    }
  }, [position.address]);

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    await onSubmit({ severity, description, address });
    setLoading(false);
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>Reportar Alagamento</h2>
          <button className="modal-close" onClick={onClose}>
            ✕
          </button>
        </div>

        <div className="modal-coords">
          📍 {position.lat.toFixed(5)}, {position.lng.toFixed(5)}
        </div>

        {position.frequentArea && (
          <div className="frequent-warning">
            ⚠️ Esta região tem histórico de alagamentos —{" "}
            <strong>{position.frequentArea.count} ocorrências</strong> nos últimos 30 dias.
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <label>Gravidade</label>
          <div className="severity-options">
            {[
              { value: "leve", label: "Leve", emoji: "🟡" },
              { value: "moderado", label: "Moderado", emoji: "🟠" },
              { value: "grave", label: "Grave", emoji: "🔴" },
            ].map((opt) => (
              <button
                key={opt.value}
                type="button"
                className={`severity-btn ${severity === opt.value ? "active" : ""}`}
                data-severity={opt.value}
                onClick={() => setSeverity(opt.value)}
              >
                {opt.emoji} {opt.label}
              </button>
            ))}
          </div>

          <label>Endereço / Referência</label>
          <input
            type="text"
            placeholder="Ex: Rua das Flores, 123 - Centro"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
          />

          <label>Descrição</label>
          <textarea
            placeholder="Descreva a situação... Ex: Água cobrindo a calçada, trânsito parado"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
          />

          <button type="submit" className="submit-btn" disabled={loading}>
            {loading ? "Enviando..." : "Enviar Reporte"}
          </button>
        </form>
      </div>
    </div>
  );
}
