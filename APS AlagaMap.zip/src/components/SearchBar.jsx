import { useState } from "react";
import { toast } from "react-toastify";
import "./SearchBar.css";

export default function SearchBar({ onLocationFound }) {
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState([]);
  const [showResults, setShowResults] = useState(false);

  async function handleSearch(e) {
    e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    setResults([]);

    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=5&countrycodes=br&addressdetails=1`
      );
      const data = await res.json();

      if (data.length === 0) {
        toast.warning("Nenhum local encontrado. Tente outro endereço.");
        setShowResults(false);
      } else {
        setResults(data);
        setShowResults(true);
      }
    } catch {
      toast.error("Erro ao buscar endereço.");
    } finally {
      setLoading(false);
    }
  }

  function selectResult(result) {
    onLocationFound({
      lat: parseFloat(result.lat),
      lng: parseFloat(result.lon),
      name: result.display_name,
    });
    setQuery(result.display_name.split(",")[0]);
    setShowResults(false);
    setResults([]);
  }

  return (
    <div className="search-container">
      <form onSubmit={handleSearch} className="search-form">
        <input
          type="text"
          placeholder="Buscar endereço ou região..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <button type="submit" disabled={loading}>
          {loading ? "..." : "🔍"}
        </button>
      </form>

      {showResults && results.length > 0 && (
        <ul className="search-results">
          {results.map((r, i) => (
            <li key={i} onClick={() => selectResult(r)}>
              <span className="result-icon">📍</span>
              <span className="result-text">{r.display_name}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
