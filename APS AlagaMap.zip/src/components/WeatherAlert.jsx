import { useEffect, useState } from "react";
import "./WeatherAlert.css";

export default function WeatherAlert({ lat, lng }) {
  const [alert, setAlert] = useState(null);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    async function fetchWeather() {
      try {
        const res = await fetch(
          `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&hourly=precipitation_probability,precipitation&timezone=America%2FSao_Paulo&forecast_days=1`
        );
        const data = await res.json();
        if (!data.hourly) return;

        const now = new Date();
        const times = data.hourly.time;
        const probs = data.hourly.precipitation_probability;
        const precs = data.hourly.precipitation;

        let firstRain = null;
        for (let i = 0; i < times.length; i++) {
          const t = new Date(times[i]);
          if (t < now) continue;
          if (probs[i] >= 60 || precs[i] >= 1) {
            firstRain = {
              hour: t.getHours().toString().padStart(2, "0") + ":00",
              probability: probs[i],
              precipitation: precs[i],
            };
            break;
          }
        }

        if (firstRain) setAlert(firstRain);
      } catch {
        // sem alerta se a API falhar
      }
    }

    fetchWeather();
  }, [lat, lng]);

  if (!alert || dismissed) return null;

  const isHeavy = alert.precipitation >= 5;

  return (
    <div className={`weather-alert ${isHeavy ? "heavy" : ""}`}>
      <span className="weather-icon">{isHeavy ? "⛈️" : "🌧️"}</span>
      <span className="weather-text">
        {isHeavy ? "Chuva forte" : "Chuva"} prevista hoje a partir das{" "}
        <strong>{alert.hour}</strong> ({alert.probability}% de probabilidade,{" "}
        {alert.precipitation.toFixed(1)}mm) — fique atento a alagamentos.
      </span>
      <button className="weather-close" onClick={() => setDismissed(true)}>
        ✕
      </button>
    </div>
  );
}
