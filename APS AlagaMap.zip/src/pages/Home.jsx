import { useState, useEffect, useMemo } from "react";
import {
  collection,
  addDoc,
  onSnapshot,
  query,
  orderBy,
  serverTimestamp,
} from "firebase/firestore";
import { db } from "../services/firebase";
import { useAuth } from "../contexts/AuthContext";
import FloodMap from "../components/FloodMap";
import ReportModal from "../components/ReportModal";
import SearchBar from "../components/SearchBar";
import WeatherAlert from "../components/WeatherAlert";
import {
  filterActiveReports,
  findFrequentFloodAreas,
  findFrequentAreaAt,
} from "../services/geoUtils";
import { toast } from "react-toastify";
import "./Home.css";

const DEFAULT_CENTER = [-23.5505, -46.6333]; // São Paulo

export default function Home() {
  const { user, logout } = useAuth();
  const [reports, setReports] = useState([]);
  const [clickedPosition, setClickedPosition] = useState(null);
  const [showSidebar, setShowSidebar] = useState(false);
  const [flyTo, setFlyTo] = useState(null);

  useEffect(() => {
    const q = query(collection(db, "reports"), orderBy("createdAt", "desc"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setReports(data);
    });
    return unsubscribe;
  }, []);

  const activeReports = useMemo(() => filterActiveReports(reports, 6), [reports]);
  const frequentAreas = useMemo(() => findFrequentFloodAreas(reports), [reports]);

  async function handleMapClick(latlng) {
    const inFrequentArea = findFrequentAreaAt(latlng.lat, latlng.lng, frequentAreas);
    const position = {
      ...latlng,
      address: "",
      frequentArea: inFrequentArea || null,
    };
    setClickedPosition(position);

    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latlng.lat}&lon=${latlng.lng}&addressdetails=1`
      );
      const data = await res.json();
      if (data.display_name) {
        setClickedPosition((prev) =>
          prev ? { ...prev, address: data.display_name } : prev
        );
      }
    } catch {
      // se falhar, o endereço fica vazio
    }
  }

  async function handleSubmitReport({ severity, description, address }) {
    try {
      await addDoc(collection(db, "reports"), {
        lat: clickedPosition.lat,
        lng: clickedPosition.lng,
        severity,
        description,
        address,
        userName: user.displayName || user.email,
        userId: user.uid,
        createdAt: serverTimestamp(),
      });
      toast.success("Alagamento reportado!");
      setClickedPosition(null);
    } catch {
      toast.error("Erro ao enviar reporte.");
    }
  }

  const severityLabels = { leve: "Leve", moderado: "Moderado", grave: "Grave" };
  const severityEmojis = { leve: "🟡", moderado: "🟠", grave: "🔴" };

  function formatDate(timestamp) {
    if (!timestamp) return "Agora";
    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
    return date.toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  }

  return (
    <div className="home-container">
      {/* Header */}
      <header className="home-header">
        <div className="header-left">
          <button
            className="menu-btn"
            onClick={() => setShowSidebar(!showSidebar)}
          >
            ☰
          </button>
          <h1>🌊 AlagaMap</h1>
        </div>
        <div className="header-right">
          <span className="user-name">{user.displayName || user.email}</span>
          <button className="logout-btn" onClick={logout}>
            Sair
          </button>
        </div>
      </header>

      {/* Sidebar - Feed de reportes */}
      <aside className={`sidebar ${showSidebar ? "open" : ""}`}>
        <h2>Reportes Ativos (6h)</h2>
        <div className="stats">
          <div className="stat-card">
            <span className="stat-number">{activeReports.length}</span>
            <span className="stat-label">Ativos</span>
          </div>
          <div className="stat-card">
            <span className="stat-number">
              {activeReports.filter((r) => r.severity === "grave").length}
            </span>
            <span className="stat-label">Graves</span>
          </div>
          <div className="stat-card">
            <span className="stat-number">{frequentAreas.length}</span>
            <span className="stat-label">Áreas críticas</span>
          </div>
        </div>
        <div className="feed">
          {activeReports.length === 0 && (
            <p className="empty-feed">
              Nenhum reporte ativo nas últimas 6 horas.
            </p>
          )}
          {activeReports.map((report) => (
            <div key={report.id} className="feed-item">
              <div className="feed-item-header">
                <span>
                  {severityEmojis[report.severity]}{" "}
                  {severityLabels[report.severity]}
                </span>
                <small>{formatDate(report.createdAt)}</small>
              </div>
              <p className="feed-item-desc">
                {report.description || "Sem descrição"}
              </p>
              {report.address && (
                <small className="feed-item-address">
                  📍 {report.address}
                </small>
              )}
              <small className="feed-item-user">👤 {report.userName}</small>
            </div>
          ))}
        </div>
      </aside>

      {/* Mapa */}
      <main className="map-area">
        <SearchBar onLocationFound={(loc) => setFlyTo({ ...loc, _t: Date.now() })} />
        <WeatherAlert lat={DEFAULT_CENTER[0]} lng={DEFAULT_CENTER[1]} />
        <FloodMap
          reports={activeReports}
          onMapClick={handleMapClick}
          center={DEFAULT_CENTER}
          flyTo={flyTo}
          frequentAreas={frequentAreas}
        />
        <div className="map-hint">Clique no mapa para reportar um alagamento</div>
      </main>

      {/* Modal de reporte */}
      {clickedPosition && (
        <ReportModal
          position={clickedPosition}
          onSubmit={handleSubmitReport}
          onClose={() => setClickedPosition(null)}
        />
      )}
    </div>
  );
}
