import { useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import "./Login.css";

export default function Login() {
  const [isRegister, setIsRegister] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const { login, register } = useAuth();
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);

    try {
      if (isRegister) {
        await register(email, password, name);
        toast.success("Conta criada com sucesso!");
      } else {
        await login(email, password);
        toast.success("Login realizado!");
      }
      navigate("/");
    } catch (error) {
      const messages = {
        "auth/email-already-in-use": "Este e-mail já está cadastrado.",
        "auth/invalid-email": "E-mail inválido.",
        "auth/weak-password": "Senha deve ter pelo menos 6 caracteres.",
        "auth/invalid-credential": "E-mail ou senha incorretos.",
      };
      toast.error(messages[error.code] || "Erro ao autenticar.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="login-container">
      <div className="login-card">
        <div className="login-header">
          <span className="login-icon">🌊</span>
          <h1>AlagaMap</h1>
          <p>Mapa colaborativo de alagamentos urbanos</p>
        </div>

        <form onSubmit={handleSubmit}>
          {isRegister && (
            <input
              type="text"
              placeholder="Seu nome"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          )}
          <input
            type="email"
            placeholder="E-mail"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Senha"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            minLength={6}
          />
          <button type="submit" disabled={loading}>
            {loading ? "Aguarde..." : isRegister ? "Criar Conta" : "Entrar"}
          </button>
        </form>

        <p className="login-toggle">
          {isRegister ? "Já tem conta?" : "Não tem conta?"}{" "}
          <span onClick={() => setIsRegister(!isRegister)}>
            {isRegister ? "Fazer login" : "Cadastre-se"}
          </span>
        </p>
      </div>
    </div>
  );
}
