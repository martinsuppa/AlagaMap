import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyD9QjViXrTEMOKW_yhqP3kuLlHzifeAW54",
  authDomain: "alagamap.firebaseapp.com",
  projectId: "alagamap",
  storageBucket: "alagamap.firebasestorage.app",
  messagingSenderId: "641416402910",
  appId: "1:641416402910:web:34fe0a4aba542777342f4f",
  measurementId: "G-48NJRJ6YNX",
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
