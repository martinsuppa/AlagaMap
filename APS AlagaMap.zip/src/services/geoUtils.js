// Calcula distância em metros entre dois pontos (Haversine)
export function distanceInMeters(lat1, lng1, lat2, lng2) {
  const R = 6371000;
  const toRad = (deg) => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

// Identifica regiões com histórico de alagamentos frequentes
// Critério: 3+ reportes num raio de 100m nos últimos 30 dias
export function findFrequentFloodAreas(reports, radiusMeters = 100, minCount = 3, maxAgeDays = 30) {
  const cutoff = Date.now() - maxAgeDays * 24 * 60 * 60 * 1000;

  const recent = reports.filter((r) => {
    if (!r.createdAt) return false;
    const time = r.createdAt.toDate
      ? r.createdAt.toDate().getTime()
      : new Date(r.createdAt).getTime();
    return time >= cutoff;
  });

  const visited = new Set();
  const areas = [];

  for (let i = 0; i < recent.length; i++) {
    if (visited.has(i)) continue;
    const cluster = [recent[i]];
    visited.add(i);

    for (let j = i + 1; j < recent.length; j++) {
      if (visited.has(j)) continue;
      const d = distanceInMeters(
        recent[i].lat,
        recent[i].lng,
        recent[j].lat,
        recent[j].lng
      );
      if (d <= radiusMeters) {
        cluster.push(recent[j]);
        visited.add(j);
      }
    }

    if (cluster.length >= minCount) {
      const avgLat = cluster.reduce((s, r) => s + r.lat, 0) / cluster.length;
      const avgLng = cluster.reduce((s, r) => s + r.lng, 0) / cluster.length;
      areas.push({
        lat: avgLat,
        lng: avgLng,
        count: cluster.length,
        radius: radiusMeters,
      });
    }
  }

  return areas;
}

// Verifica se uma posição está dentro de alguma área frequente
export function findFrequentAreaAt(lat, lng, frequentAreas) {
  return frequentAreas.find((area) => {
    const d = distanceInMeters(lat, lng, area.lat, area.lng);
    return d <= area.radius;
  });
}

// Filtra apenas reportes ativos (últimas N horas)
export function filterActiveReports(reports, hours = 6) {
  const cutoff = Date.now() - hours * 60 * 60 * 1000;
  return reports.filter((r) => {
    if (!r.createdAt) return true;
    const time = r.createdAt.toDate
      ? r.createdAt.toDate().getTime()
      : new Date(r.createdAt).getTime();
    return time >= cutoff;
  });
}
